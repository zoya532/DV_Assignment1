import json
from pymongo import MongoClient
import pandas as pd
import numpy as np
import re

MONGO_URI = "mongodb://localhost:27017/"
client = MongoClient(MONGO_URI)

with open("D:/Study course/bonus_dataset.json", "r") as file:
  data = [json.loads(line) for line in file]

df = pd.DataFrame(data)

df["pragma"] = df["pragma"].fillna("None")

label_columns = ["label_para", "label_function_call", "label_nested_loop", "label_reduction", "label_task", "label_simd", "label_target"]
for col in label_columns:
    df[col] = df[col].fillna(0).astype(int)  


df.loc[(df["label_para"] == 1) & (df["pragma"] == "None"), "pragma"] = "omp parallel for"

df.loc[(df["label_para"] == 0), "pragma"] = "None"

df.loc[(df["label_reduction"] == 1) & (~df["pragma"].str.contains("reduction", na=False)), "label_reduction"] = 0

df.loc[(df["label_simd"] == 1) & (~df["pragma"].str.contains("simd", na=False)), "label_simd"] = 0

df.loc[(df["label_target"] == 1) & (~df["pragma"].str.contains("target", na=False)), "label_target"] = 0

df["code"] = df["code"].apply(lambda x: re.sub(r'\s+', ' ', x).strip())

df["code"] = df["code"].apply(lambda x: x.replace("{ ", "{").replace(" }", "}").replace("{", " {\n").replace("}", "\n}"))

df["ID"] = df["ID"].astype(int)


df["anomaly_task"] = df.apply(lambda row: 1 if (row["label_task"] == 1 and "task" not in row["pragma"]) else 0, axis=1)


df.to_excel("D:/Study course/cleaned_dataset.xlsx", index=False, engine='openpyxl')

db = client["bonus_database"] 
collection = db["bonus_collection"]  

collection.insert_many(df)
print("Data Inserted")

client.close()

